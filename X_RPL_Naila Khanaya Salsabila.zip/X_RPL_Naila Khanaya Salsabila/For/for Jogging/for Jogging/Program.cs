﻿using System;
namespace forJogging
{
    class Program
    {
        static void Main (string[] args)
        {
            Console.WriteLine("CATATAN JOGGING PAGI");
            Console.WriteLine("Target hari ini: 5 Putaran Lapangan");

            for (int i = 1; i<= 5;  i++)
            {
                Console.WriteLine("[Putaran " + i + "] Berhasil menyelesaikan putaran ke-" + i + "!");
            }
            Console.WriteLine("Selamat! Target jogging pagi ini selesai. Jaga tubuh agar tetap segar setiap hari!");
        }
    }
}
