﻿using System;
namespace forMembukaTirai
{
    class Program
    {
        static void Main (string[] args)
        {
            Console.WriteLine("RUTINITAS HARIAN RUMAH: MEMBUKA TIRAI");
            Console.WriteLine("Matahari sudah terbit, waktunya membiarkan cahaya masuk ke dalam rumah");

            for (int i= 1; i <= 4; i++ )
            {
                Console.WriteLine("Tirai jendela ke-" + i + ": Dibuka lebar, cahaya matahari pagi langsung masuk menyinari ruangan.");
            }
            Console.WriteLine("Selesai! Seluruh ruangan di rumah kini terasa hangat dan terang.");
        }
    }
}