﻿using System;
namespace forMenyiramTanaman
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("KEGIATAN PAGI: MENYIRAM TANAMAN");
            Console.WriteLine("Menyiapkan selang air dan mulai menyiram deretan pot");

            for (int i = 1; i<= 5; i++)
            {
                Console.WriteLine("Pot tanaman ke-" + i + ": Disiram air sampai tanahnya cukup basah.");
            }
            Console.WriteLine("Selesai! Semua tanaman tampak segar dan siap menyambut matahari pagi.");
        }
    }
}
