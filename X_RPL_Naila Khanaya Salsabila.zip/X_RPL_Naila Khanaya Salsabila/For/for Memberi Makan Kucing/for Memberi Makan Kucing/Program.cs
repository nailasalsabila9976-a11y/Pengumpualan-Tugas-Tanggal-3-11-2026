﻿using System;
namespace forMemberiMakanKucing
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("AWAL HARI YANG SEGAR");
            Console.WriteLine("Menyiapkan mangkuk dan makanan kering untuk kucing kesayagan...");

            for (int i = 1; i <= 3; i++)
            {
                Console.WriteLine("Mangkuk kucing ke-" + i + ": Diisi penuh dengan makanan kucing yang lezat dan harum.");
            }
            Console.WriteLine("Lihat! Semua kucing tampak lahap saat makan.");
        }
    }
}