﻿using System;
namespace forMengadukAdonan
{
    class Program
    {
        static void Main (string[] Args)
        {
            Console.WriteLine("SIMULASI MEMASAK: MENGADUK ADONAN");
            Console.WriteLine("Mulai mengaduk adonan kue agar tercampur sempurna");

            for (int i = 1; i <= 5; i++)
            {
                Console.WriteLine("Adukan ke-" + i + ": Adonan diputar perlahan dan merata.");
            }
            Console.WriteLine("Adonan sudah sempurna dan siap dipanggang!");
        }
    }
}