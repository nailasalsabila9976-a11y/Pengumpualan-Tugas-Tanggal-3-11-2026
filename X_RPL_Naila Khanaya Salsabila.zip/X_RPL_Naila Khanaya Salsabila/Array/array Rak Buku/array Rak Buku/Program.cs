﻿using System;
namespace arrayRakBuku
{
    class Program
    {
        static void Main (string [] args)
        {
            Console.WriteLine("RAK BUKU");

            string[] rakBuku = { "Novel", "Buku Sejarah", "Buku Antologi", "Kamus Indonesia-Inggris", "Panduan EYD" };

            Console.WriteLine("Buku di indeks ke-0: " + rakBuku[0]);
            Console.WriteLine("Buku di indeks ke-1: " + rakBuku[1]);
            Console.WriteLine("Buku di indeks ke-2: " + rakBuku[2]);
            Console.WriteLine("Buku di indeks ke-3: " + rakBuku[3]);
            Console.WriteLine("Buku di indeks ke-4: " + rakBuku[4]);

            Console.WriteLine("Total seluruh buku di rak ada " + rakBuku.Length + " buah.");
            Console.WriteLine("Buku siap dibaca kapan saja."); 
        }
    }
}