﻿using System;
namespace arrayRakBumbu
{
    class Program
    {
        static void Main (string[] args)
        {
            Console.WriteLine("RAK BUMBU GANTUNG");

            string[] rakBumbu = { "Botol Garam", "Botol Merica", "Botol Gula", "Botol Ketumbar" };

            Console.WriteLine("Posisi ke-0 (paling kiri): " + rakBumbu[0]);
            Console.WriteLine("Posisi ke-1: " + rakBumbu[1]);
            Console.WriteLine("Posisi ke-2: " + rakBumbu[2]);
            Console.WriteLine("Posisi ke-3 (paling kanan): " + rakBumbu[3]);

            Console.WriteLine("Total bumbu yang tersusun rapi di rak gantung: " + rakBumbu.Length + " botol.");
        }
    }
}