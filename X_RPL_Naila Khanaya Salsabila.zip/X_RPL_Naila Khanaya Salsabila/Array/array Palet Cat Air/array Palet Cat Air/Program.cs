﻿using System;
namespace arrayPaletCatAir
{
    class Program
    {
        static void Main (string [] args)
        {
            Console.WriteLine("MENYIAPKAN PALET CAT AIR");
            Console.WriteLine("Menuangkan berbagai warna cat ke pinggiran plastik sebelum melukis...");

            string[] paletWarna= { "Biru", "Putih", "Hitam", "Merah" };

            Console.WriteLine("Cekungan warna ke-0: Cat warna " + paletWarna[0]);
            Console.WriteLine("Cekungan warna ke-1: Cat warna " + paletWarna[1]);
            Console.WriteLine("Cekungan warna ke-2: Cat warna " + paletWarna[2]);
            Console.WriteLine("Cekungan warna ke-3: Cat warna " + paletWarna[3]);

            Console.WriteLine("Total ada " + paletWarna.Length + " cekungan warna di atas palet.");
            Console.WriteLine("Palet siap digunakan untuk melukis di atas kertas canvas.");
        }
    }
}