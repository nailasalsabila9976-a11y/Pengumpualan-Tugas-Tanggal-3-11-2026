﻿using System;
namespace arrayTermometerSuhu
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("MEMORI TERMOMETER DIGITAL");

            double[] riwayatSuhu = { 36.5, 37.2, 36.8 };

            Console.WriteLine("Cek ke-0 (Pagi): " + riwayatSuhu[0] + " derajat Celsius");
            Console.WriteLine("Cek ke-1 (Siang): " + riwayatSuhu[1] + " derajat Celsius");
            Console.WriteLine("Cek ke-2 (Malam): " + riwayatSuhu[2] + " derajat Celsius");

            Console.WriteLine("Total ada " + riwayatSuhu.Length + " catatan suhu tersimpan di memori.");
            Console.WriteLine("Pemantauan suhu tubuh hari ini tercatat dengan baik.");
        }
    }
}