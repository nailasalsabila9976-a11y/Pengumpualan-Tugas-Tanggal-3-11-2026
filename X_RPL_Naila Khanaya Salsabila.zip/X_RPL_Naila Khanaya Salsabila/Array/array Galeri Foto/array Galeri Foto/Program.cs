﻿using System;
namespace arrayGaleriFoto
{
    class Program
    {
        static void Main (string[] args)
        {
            Console.WriteLine("GALERI FOTO LIBURAN");

            string[] galeriFoto = { "Foto_Pantai_Pagi.jpg", "Foto_Makan_Bakso.jpg", "Foto_Sunset_Sore.jpg", "Foto_Museum,jpg" };

            Console.WriteLine("Foto indeks ke-0: " + galeriFoto[0]);
            Console.WriteLine("Fot indeks ke-1: " + galeriFoto[1]);
            Console.WriteLine("Foto indeks ke-2: " + galeriFoto[2]);
            Console.WriteLine("Foto indeks ke-3: " + galeriFoto[3]);

            Console.WriteLine("Total foto " + galeriFoto.Length + " file foto di dalam album liburan.");
        }
    }
}