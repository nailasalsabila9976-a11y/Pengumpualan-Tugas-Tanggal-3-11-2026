﻿using System;
using System.Collections.Generic;
namespace listAplikasiHP
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("SMARTPHONE: APLIKASI UTAMA");
            Console.WriteLine("Melihat daftar aplikasi yang sering dibuka di layar utama");

            List<string> aplikasiHp = new List<string>();

            aplikasiHp.Add("Aplikasi WhatsApp");
            aplikasiHp.Add("Aplikasi Instagram");
            aplikasiHp.Add("Aplikasi Duolingo");
            aplikasiHp.Add("Aplikasi Spotify");
            aplikasiHp.Add("Aplikasi Catatan");

            Console.WriteLine("Aplikasi ke-0: " + aplikasiHp[0]);
            Console.WriteLine("Aplikasi ke-1: " + aplikasiHp[1]);
            Console.WriteLine("Aplikasi ke-2: " + aplikasiHp[2]);
            Console.WriteLine("Aplikasi ke-3: " + aplikasiHp[3]);
            Console.WriteLine("Aplikasi ke-4: " + aplikasiHp[4]);

            Console.WriteLine("Total ada " + aplikasiHp.Count + " aplikasi utama di layar.");
            Console.WriteLine("Siap digunakan untuk beraktivitas.");
        }
    }
}