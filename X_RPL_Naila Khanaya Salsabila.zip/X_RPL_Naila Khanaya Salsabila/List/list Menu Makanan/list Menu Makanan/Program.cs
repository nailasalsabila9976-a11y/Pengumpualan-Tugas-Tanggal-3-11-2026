﻿using System;
using System.Collections.Generic; 
namespace listMenuMakanan
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("DAFTAR MENU MAKANAN FAVORIT");
            Console.WriteLine("Mendaftar menu makanan yang ingin dicicipi minggu ini");

            List<string> menuMakanan = new List<string>();

            menuMakanan.Add("Es Krim Rasa Choco Mint");
            menuMakanan.Add("Bakmi");
            menuMakanan.Add("Nasi Ayam Geprek");

            Console.WriteLine("Menu ke-0: " + menuMakanan[0]);
            Console.WriteLine("Menu ke-1: " + menuMakanan[1]);
            Console.WriteLine("Menu ke-2: " + menuMakanan[2]);

            Console.WriteLine("Total ada " + menuMakanan.Count + " menu makanan di dalam daftar.");
            Console.WriteLine("Siap pilih salah satu untuk dicoba!");
        }
    }
}