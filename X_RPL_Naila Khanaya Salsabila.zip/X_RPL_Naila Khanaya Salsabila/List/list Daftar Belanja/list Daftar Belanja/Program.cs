﻿using System;
using System.Collections.Generic; 
namespace listDaftarBelanja
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("DAFTAR BELANJAAN MINIMARKET");
            Console.WriteLine("Membuat daftar barang yang akan dibeli...");

            List<string> daftarBelanja = new List<string>();

            daftarBelanja.Add("Susu Kotak UHT");
            daftarBelanja.Add("Roti Tawar Gandum");
            daftarBelanja.Add("Telur Ayam 1 Kg");

            Console.WriteLine("Item ke-0: " + daftarBelanja[0]);
            Console.WriteLine("Item ke-1: " + daftarBelanja[1]);
            Console.WriteLine("Item ke-2: " + daftarBelanja[2]);

            Console.WriteLine("Total ada " + daftarBelanja.Count + " barang di dalam keranjang belanja.");
            Console.WriteLine("Siap menuju kasir untuk membayar.");
        }
    }
}