﻿using System;
using System.Collections.Generic;
namespace listKontakTeman
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("HP: DAFTAR KONTAK TEMAN DEKAT");

            List<string> kontakTeman = new List<string>();

            kontakTeman.Add("Lana");
            kontakTeman.Add("Rubi");
            kontakTeman.Add("Rainia");
            kontakTeman.Add("Elvano");
            kontakTeman.Add("Lintang");
            kontakTeman.Add("Elang");

            Console.WriteLine("Kontak ke-0: " + kontakTeman[0]);
            Console.WriteLine("Kontak ke-1: " + kontakTeman[1]);
            Console.WriteLine("Kontak ke-2: " + kontakTeman[2]);
            Console.WriteLine("Kontak ke-3: " + kontakTeman[3]);
            Console.WriteLine("Kontak ke-4: " + kontakTeman[4]);
            Console.WriteLine("Kontak ke-5: " + kontakTeman[5]);

            Console.WriteLine("Total ada " + kontakTeman.Count + " nama teman yang tersimpan di kontak.");
            Console.WriteLine("Semua kontak berhasil disimpan.");
        }
    }
}