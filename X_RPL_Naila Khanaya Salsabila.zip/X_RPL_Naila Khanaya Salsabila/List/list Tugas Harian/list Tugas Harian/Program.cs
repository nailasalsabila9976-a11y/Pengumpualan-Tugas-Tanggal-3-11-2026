﻿using System;
using System.Collections.Generic; 
namespace listDaftarHarian
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("PRODUKTIVITAS: TO-DO LIST HARIAN");
            Console.WriteLine("Daftar kegiatan yang harus diselesaikan hari ini");

            List<string> daftarTugas = new List<string>();

            daftarTugas.Add("Mengerjakan tugas C#");
            daftarTugas.Add("Membereskan kamar tidur");
            daftarTugas.Add("Menyiram tanaman");

            Console.WriteLine("Tugas ke-0: " + daftarTugas[0]);
            Console.WriteLine("Tugas ke-1: " + daftarTugas[1]);
            Console.WriteLine("Tugas ke-2: " + daftarTugas[2]);

            Console.WriteLine("Total ada " + daftarTugas.Count + " tugas yang harus diselesaikan.");
            Console.WriteLine("Semangat mencicil satu persatu.");
        }
    }
}