﻿using System;
namespace whileMenyetrikaBaju
{
    class Program
    {
        static void Main (string[] args)
        {
            Console.WriteLine("MENYETRIKA PAKAIAN");
            Console.WriteLine("Nyalakan setrika, tunggu hingga panas, dan bentangkan baju di atas meja...");

            int tingkatKekusutan = 6;
            int sesiGosok = 1;
            while (tingkatKekusutan > 0)
            {
                if (tingkatKekusutan == 6)
                {
                    Console.WriteLine("Sesi " + sesiGosok + ": Baju masih sangat kusut, setrika bagian kerah dan pundak.");
                }
                else if (tingkatKekusutan >= 4)
                {
                    Console.WriteLine("Sesi " + sesiGosok + ": Bagian badan baju mulai licin dan lurus.");
                }
                else
                {
                    Console.WriteLine("Sesi " + sesiGosok + ": Sedikit lagi bagian lengan dan lipatan terakhir dirapikan.");
                }
                tingkatKekusutan = tingkatKekusutan - 2;

                if (tingkatKekusutan < 0)
                {
                    tingkatKekusutan = 0;
                }
                Console.WriteLine("-> Sisa area kusut pada baju: " + tingkatKekusutan + " tingkat.");

                sesiGosok++;
            }
            Console.WriteLine("Kondisi Berhenti: Baju sudah rapi, halus, dan siap dilipat!");
            Console.WriteLine("Pekerjaan menyetrika selesai.");
        }
    }
}