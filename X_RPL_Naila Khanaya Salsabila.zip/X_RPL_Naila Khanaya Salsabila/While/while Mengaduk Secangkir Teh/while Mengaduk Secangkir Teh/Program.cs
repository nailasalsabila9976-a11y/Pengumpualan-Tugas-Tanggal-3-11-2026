﻿using System;
namespace whileMengadukSecangkirTeh
{
    class Program
    {
        static void Main (string[] args)
        {
            Console.WriteLine("MENGADUK TEH HANGAT");
            Console.WriteLine("Masukkan gula secukupnya, lalu mulai aduk perlahan...");

            int i = 1;
            while (i<= 10)
            {
                Console.WriteLine("Adukan ke-" + i + ": Gula perlahan larut dan menyatu dengan air teh.");

                i++; 
            }
            Console.WriteLine("Selesai! Teh hangat siap dinikmati.");
        }
    }
}