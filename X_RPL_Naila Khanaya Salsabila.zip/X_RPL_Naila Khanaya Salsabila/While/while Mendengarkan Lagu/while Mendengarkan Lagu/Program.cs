﻿using System;
namespace whileMendengarkanLagu
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("HIBURAN: MENDENGARKAN PLAYLIST LAGU");
            Console.WriteLine("Memilih lagu favorit dan mengaktifkan mode 'Repeat'...");

            bool statusRepeat = true;
            int putaranLagu = 1;
            while (statusRepeat)
            {
                if (putaranLagu == 1)
                {
                    Console.WriteLine("Pemutaran ke-" + putaranLagu + ": Memutar lagu favorit dari awal.");
                }
                else if (putaranLagu == 3)
                {
                    Console.WriteLine("Pemutaran ke-" + putaranLagu + ": Lagu sudah diputar beberapa kali.");

                    statusRepeat = false;
                    Console.WriteLine("-> Tombol 'Repeat' dimatikan oleh pengguna.");
                }
                else
                {
                    Console.WriteLine("Pemutaran ke-" + putaranLagu + ": Lagu diputar secara otomatis.");
                }
                putaranLagu++;
            }
            Console.WriteLine("Kondisi Berhenti: Pemutaran lagu berhenti. Anda menekan tombol pause.");
            Console.WriteLine("Sesi mendengarkan musik selesai."); 
        }
    }
}