﻿using System;
namespace whileMencuciPiring
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("MEMBERSIHKAN PIRING KOTOR");
            Console.WriteLine("Tumpukan piring kotor di dalam bak menanti untuk dibersihkan...");

            int jumlahPiring = 7;
            int nomorCuci = 1;
            while (jumlahPiring > 0)
            {
                if (jumlahPiring > 4)
                {
                    Console.WriteLine("Pencucian ke-" + nomorCuci + ": Piring masih banyak, semangat menyabuni tumpukan atas!");
                }
                else if (jumlahPiring > 1)
                {
                    Console.WriteLine("Pencucian ke-" + nomorCuci + ": Mulai terasa ringan, piring kotor tinggal separuh.");
                }
                else
                {
                    Console.WriteLine("Pencucian ke-" + nomorCuci + ": Ini piring terakhir yang ada di bak cuci!");
                }
                jumlahPiring = jumlahPiring - 1;
                Console.WriteLine("-> Sisa piring kotor di bak cuci saat ini: "+ jumlahPiring + " buah.");

                nomorCuci++;
            }
            Console.WriteLine("Kondisi Berhenti: Bak cuci piring sudah kosong dan bersih.");
            Console.WriteLine("Semua piring selesai dicuci dan disusun rapi di rak pengering!");
        }
    }
}