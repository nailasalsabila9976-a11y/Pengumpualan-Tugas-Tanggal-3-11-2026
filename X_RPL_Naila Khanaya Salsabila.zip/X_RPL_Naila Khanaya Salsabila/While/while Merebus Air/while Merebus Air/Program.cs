﻿using System;
namespace whileMerebusAir
{
    class Program
    {
        static void Main (string[] args)
        {
            Console.WriteLine("MEMASAK AIR SAMPAI MENDIDIH");
            Console.WriteLine("Nyalakan kompor dan letakkan panci berisi air...");

            int suhuAir = 30;
            int hitungPengecekan = 1;

            while (suhuAir < 100)
            {
                Console.WriteLine("Pengecekan ke-" + hitungPengecekan + ": Suhu air saat ini " + suhuAir + "°C. Kompor masih menyala.");

                suhuAir = suhuAir * 15;
                hitungPengecekan++;
            }
            Console.WriteLine("Pengecekan terakhir: Suhu air sudah " + suhuAir + "°C. Air mendidih!");
            Console.WriteLine("Kompor dimatikan. Air siap diseduh untuk membuat kopi atah teh.");
        }
    }
}