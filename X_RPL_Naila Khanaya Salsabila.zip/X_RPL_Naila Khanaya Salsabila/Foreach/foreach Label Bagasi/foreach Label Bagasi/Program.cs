﻿using System;
namespace foreachLabelBagasi
{
    class Program
    {
        static void Main (string[] args)
        {
            Console.WriteLine("BANDARA: MEMASANG LABEL BAGASI");
            Console.WriteLine("Petugas berdiri di loket check-in, bersiap melayani para penumpang...");

            string[] daftarKoper = { "Koper Penumpang A (Kelas Ekonomi)", "Koper Penumpang B (Kelas Bisnis)", "Koper Penumpang C (Prioritas)" };

            foreach (string koper in daftarKoper)
            {
                Console.WriteLine("Melayani " + koper + ": Petugas menempelkan stiker kode batang penerbangan pada bagian pegangannya.");
            }
            Console.WriteLine("Selesai! Semua koper di antrean check-in telah diberi label dan siap dimasukkan ke bagasi pesawat.");
        }
    }
}