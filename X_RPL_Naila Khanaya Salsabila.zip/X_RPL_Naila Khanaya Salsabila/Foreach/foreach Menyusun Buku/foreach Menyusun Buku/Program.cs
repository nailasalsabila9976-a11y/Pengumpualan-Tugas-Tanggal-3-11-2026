﻿using System;
namespace foreachMenyusunBuku
{
    class Program
    {
        static void Main (string[] args)
        {
            Console.WriteLine("MENYUSUN KOLEKSI BUKU");
            Console.WriteLine("Membuka kardus berisi novel-novel dan siap memilahnya");

            string[] kardusBuku = { "Novel Fiksi Sains #01", "Novel Petualangan #02", "Novel Misteri #03", "Novel Fantasi #04" };

            foreach (string buku in kardusBuku)
            {
                Console.WriteLine("Mengambil " + buku + ": Memeriksa nomor seri, lalu menyelipkannya ke rak yang tepat.");
            }
            Console.WriteLine("Selesai! Semua novel dari kardus sudah tertata rapi di rak buku.");
        }
    }
}