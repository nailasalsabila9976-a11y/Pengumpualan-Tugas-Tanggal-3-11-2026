﻿using System;
namespace foreachMenuangSirup
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("MENUANGKAN SIRUP UNTUK TAMU.");
            Console.WriteLine("Siapkan botol sirup manis dan nampan berisi gelas kosong...");

            string[] barisGelas = { "Gelas Tamu Pertama", "Gelas Tamu Kedua", "Gelas Tamu Ketiga", "Gelas Tamu Keempat" };

            foreach (string gelas in barisGelas)
            {
                Console.WriteLine("Menuangkan ke " + gelas + ": Sirup manis dituangkan secukupnya, siap disajikan.");
            }
            Console.WriteLine("Selesai! Semua gelas di atas nampan sudah terisi sirup dan siap dihidangkan.");
        }
    }
}