﻿using System;
namespace foreachKurirSurat
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("KURIR: MEMBAGIKAN SURAT");
            Console.WriteLine("Mempersiapkan tumpukan surat di tas untuk diantar...");

            string[] daftarSurat = { "Surat Tagihan Listrik", "Undangan Pernikahan", "Paket Buku Paket", "Katalog Belanja" };

            foreach (string surat in daftarSurat)
            {
                Console.WriteLine("Mengantar ke tujuan: " + surat + " berhasil dimasukkan ke dalam kotak pos.");
            }
            Console.WriteLine("Selesai! Semua surat di dalam tas kurir sudah habis dibagikan.");
        }
    }
}
    
    
        
        
           
 

    
    


