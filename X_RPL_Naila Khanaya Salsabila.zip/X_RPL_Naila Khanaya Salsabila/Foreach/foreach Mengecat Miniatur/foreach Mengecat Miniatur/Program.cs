﻿using System;
namespace foreachMengecatMiniatur
{
    class Program
    {
        static void Main (string[] args)
        {
            Console.WriteLine("MENGECAT MINIATUR ACTION FIGURE");
            Console.WriteLine("Menyiapkan palet cat, kuas kecil, dan bagian-bagian yan belum dirakit...");

            string[] bagianRobot = { "Kepala Robot", "Tangan Kanan", "Tangan Kiri", "Kaki Kanan", "Kaki Kiri", "Badan Utama" };

            foreach (string bagian in bagianRobot)
            {
                Console.WriteLine("Mengerjakan " + bagian + ": Mengoleskan cat dasar menggunakan kuas kecil dengan hati-hati.");
            }
            Console.WriteLine("Selesai! Semua bagian robot telah selesai dicat dasar dan siap dikeringkan.");
        }
    }
}