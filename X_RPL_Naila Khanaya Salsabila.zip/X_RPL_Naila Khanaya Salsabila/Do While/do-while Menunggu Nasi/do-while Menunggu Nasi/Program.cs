﻿using System;
namespace doWhileMenungguNasi
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("MENUNGGU NASI MATANG");

            int pengecekan = 1;
            do
            {
                Console.WriteLine("Pengecekan ke-" + pengecekan + ": Nasi masih dimasak dan belum matang.");

                pengecekan++;
            }
            while (pengecekan <= 3); 

            Console.WriteLine("Lampu indikator berubah, nasi sudah matang dan siap diambil.");
        }
    }
}