﻿using System;
namespace doWhileChargeHP
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("MENGISI DAYA BATERAI HP");
            Console.WriteLine("Menghubungkan charger ke stopkontak...");

            int persentaseBaterai = 90;
            do
            {
                Console.WriteLine("Baterai terisi: " + persentaseBaterai + "% - Masih mengisi...");
                persentaseBaterai = persentaseBaterai + 5;
            }
            while (persentaseBaterai <= 100); 
            Console.WriteLine("Selesai! Baterai HP sudah penuh 100% dan kabel charger bisa dicabut.");
        }
    }
}