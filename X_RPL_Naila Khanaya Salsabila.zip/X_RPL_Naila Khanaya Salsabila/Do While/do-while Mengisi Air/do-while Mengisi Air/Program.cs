﻿using System;
namespace doWhileMengisiAir
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("MENGISI EMBER DENGAN SELANG");
            Console.WriteLine("Nyalakan keran air untuk mengisi ember kosong...");

            int literAir = 1;
            do
            {
                Console.WriteLine("Mengisi air: Ember terisi sebanyak " + literAir + " liter.");

                literAir++;
            }
            while (literAir <= 5); 

            Console.WriteLine("Selesai, ember sudah penuh berisi 5 liter air dan keran dimatikan.");
        }
    }
}