﻿using System;
namespace doWhileMenyikatGigi
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("MENYIKAT GIGI MALAM HARI");
            Console.WriteLine("Ambil sikat gigi dan oleskan pasta gigi...");

            int putaranSikat = 1;
            do
            {
                Console.WriteLine("Gerakan sikat ke-" + putaranSikat + ": Menyikat gigi dengan perlahan.");

                putaranSikat++;
            }
            while (putaranSikat <= 4); 

            Console.WriteLine("Berkumur-kumur dengan air bersih, gigi sudah bersih dan siap tidur.");
        }
    }
}