﻿using System;
namespace doWhileMengetukPintu
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("MENGETUK PINTU RUMAH TEMAN");

            int ketukan = 1;
            do
            {
                Console.WriteLine("Ketukan ke-" + ketukan + ": Tok... tok... tok...");
                ketukan++;
            }
            while (ketukan <= 3); 

            Console.WriteLine("Pintu akhirnya dibukakan dari dalam oleh pemilik rumah.");
        }
    }
}